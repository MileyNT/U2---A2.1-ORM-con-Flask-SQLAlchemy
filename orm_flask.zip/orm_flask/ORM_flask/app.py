from flask import Flask, render_template, request, redirect, url_for
from config import Config
from models import db
import controllers

app = Flask(__name__)
app.config.from_object(Config)


db.init_app(app)


@app.route('/')
@app.route('/juegos')
def index():
    juegos = controllers.obtener_juegos()
    return render_template('index.html', juegos=juegos)

@app.route('/juegos/agregar', methods=['GET', 'POST'])
def agregar():
    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        precio = request.form['precio']
        
        controllers.insertar_juego(nombre, descripcion, precio)
        return redirect(url_for('index'))
        
    return render_template('agregar.html')

@app.route('/juegos/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    juego = controllers.obtener_juego_por_id(id)
    if not juego:
        return redirect(url_for('index'))

    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        precio = request.form['precio']
        
        controllers.actualizar_juego(id, nombre, descripcion, precio)
        return redirect(url_for('index'))

    return render_template('editar.html', juego=juego)

@app.route('/juegos/eliminar/<int:id>', methods=['POST'])
def eliminar(id):
    controllers.eliminar_juego(id)
    return redirect(url_for('index'))

# Crear las tablas en MySQL automáticamente si no existen
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, port=8000)
